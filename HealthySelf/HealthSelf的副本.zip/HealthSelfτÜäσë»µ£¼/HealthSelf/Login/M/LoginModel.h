//
//  ModelLogin.h
//  HealthSelf
//
//  Created by 李育腾 on 2022/12/5.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LoginModel : NSObject

@end

NS_ASSUME_NONNULL_END
