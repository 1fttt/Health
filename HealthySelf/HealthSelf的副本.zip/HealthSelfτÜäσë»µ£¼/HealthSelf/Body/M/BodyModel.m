//
//  ModelBody.m
//  HealthSelf
//
//  Created by 李育腾 on 2022/12/12.
//

#import "BodyModel.h"

@implementation BodyModel

@end
