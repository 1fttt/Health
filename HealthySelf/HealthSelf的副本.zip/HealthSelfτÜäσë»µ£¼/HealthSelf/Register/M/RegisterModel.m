//
//  ModelRegister.m
//  HealthSelf
//
//  Created by 李育腾 on 2022/12/5.
//

#import "RegisterModel.h"

@implementation RegisterModel

@end
