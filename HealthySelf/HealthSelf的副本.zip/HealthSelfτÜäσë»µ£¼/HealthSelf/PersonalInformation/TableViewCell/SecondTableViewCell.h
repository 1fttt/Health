//
//  SecondTableViewCell.h
//  HealthSelf
//
//  Created by 张佳慧 on 2022/12/17.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SecondTableViewCell : UITableViewCell
@end

NS_ASSUME_NONNULL_END
