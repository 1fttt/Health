//
//  ThirdTableViewCell.h
//  HealthSelf
//
//  Created by 张佳慧 on 2022/12/17.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ThirdTableViewCell : UITableViewCell
@property (nonatomic, strong)UILabel* label;
@property (nonatomic, strong)UIImageView* smallView;
@property (nonatomic, strong)UIImageView* labelImageView;
@end

NS_ASSUME_NONNULL_END
