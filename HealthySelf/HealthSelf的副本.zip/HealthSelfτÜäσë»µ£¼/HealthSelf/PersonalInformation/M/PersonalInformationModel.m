//
//  PersonalInformationModel.m
//  HealthSelf
//
//  Created by 张佳慧 on 2022/12/17.
//

#import "PersonalInformationModel.h"

@implementation PersonalInformationModel

@end
