//
//  PersonalInformationModel.h
//  HealthSelf
//
//  Created by 张佳慧 on 2022/12/17.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PersonalInformationModel : NSObject

@end

NS_ASSUME_NONNULL_END
