//
//  SetTableViewCell.h
//  HealthSelf
//
//  Created by 张佳慧 on 2022/12/18.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SetTableViewCell : UITableViewCell
@property (nonatomic, strong)UILabel* label;
@property (nonatomic, strong)UIImageView* smallView;
@end

NS_ASSUME_NONNULL_END
