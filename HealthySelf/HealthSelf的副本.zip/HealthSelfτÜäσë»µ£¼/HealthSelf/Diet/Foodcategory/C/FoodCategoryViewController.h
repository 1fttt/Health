//
//  FoodCategoryViewController.h
//  HealthSelf
//
//  Created by 李育腾 on 2023/1/5.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FoodCategoryViewController : UIViewController
@property (nonatomic, strong)NSDictionary *foodCateDictionary;
@property (nonatomic, assign)NSInteger setTitleNameId;
@end

NS_ASSUME_NONNULL_END
