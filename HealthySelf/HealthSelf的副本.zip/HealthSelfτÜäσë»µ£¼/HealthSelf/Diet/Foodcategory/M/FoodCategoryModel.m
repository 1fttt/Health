//
//  FoodCategoryModel.m
//  HealthSelf
//
//  Created by 李育腾 on 2023/1/5.
//

#import "FoodCategoryModel.h"

@implementation FoodCategoryModel

@end
