//
//  FoodCategoryModel.h
//  HealthSelf
//
//  Created by 李育腾 on 2023/1/5.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FoodCategoryModel : NSObject

@end

NS_ASSUME_NONNULL_END
