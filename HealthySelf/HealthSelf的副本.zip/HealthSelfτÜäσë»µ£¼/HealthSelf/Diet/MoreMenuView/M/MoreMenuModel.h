//
//  MoreMenuModel.h
//  HealthSelf
//
//  Created by 李育腾 on 2023/1/13.
//

#import <JSONModel/JSONModel.h>

NS_ASSUME_NONNULL_BEGIN

@interface MoreMenuModel : JSONModel

@end

NS_ASSUME_NONNULL_END
