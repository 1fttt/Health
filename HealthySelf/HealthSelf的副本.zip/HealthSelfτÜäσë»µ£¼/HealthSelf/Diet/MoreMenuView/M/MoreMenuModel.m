//
//  MoreMenuModel.m
//  HealthSelf
//
//  Created by 李育腾 on 2023/1/13.
//

#import "MoreMenuModel.h"

@implementation MoreMenuModel

@end
