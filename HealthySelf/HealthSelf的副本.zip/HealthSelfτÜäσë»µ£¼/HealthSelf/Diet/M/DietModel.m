//
//  ModelDiet.m
//  HealthSelf
//
//  Created by 李育腾 on 2022/12/12.
//

#import "DietModel.h"

@implementation DietModel

@end
