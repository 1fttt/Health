//
//  FoodDetailsViewController.h
//  HealthSelf
//
//  Created by 李育腾 on 2022/12/29.
//

#import "ViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface FoodDetailsViewController : ViewController
// 食物详细信息
@property (nonatomic, strong)NSDictionary *foodDetailsDiciionary;
@end

NS_ASSUME_NONNULL_END
