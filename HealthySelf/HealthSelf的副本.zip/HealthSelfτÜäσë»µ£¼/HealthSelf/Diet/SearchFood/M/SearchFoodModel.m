//
//  SearchFoodModel.m
//  HealthSelf
//
//  Created by 李育腾 on 2022/12/21.
//

#import "SearchFoodModel.h"

@implementation SearchFoodModel

@end
