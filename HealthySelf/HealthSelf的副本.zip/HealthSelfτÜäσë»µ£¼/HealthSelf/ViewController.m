//
//  ViewController.m
//  HealthSelf
//
//  Created by 李育腾 on 2022/12/5.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
