//
//  SceneDelegate.h
//  HealthSelf
//
//  Created by 李育腾 on 2022/12/5.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

